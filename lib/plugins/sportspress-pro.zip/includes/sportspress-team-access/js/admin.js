(function($) {
	$('.subsubsub .count').remove();
})(jQuery);