jQuery(document).ready(function($) {

  'use strict';

  $('#daextvffve_field_image').select2();
  $('#daextvffve_field_image_resolution').select2();

});