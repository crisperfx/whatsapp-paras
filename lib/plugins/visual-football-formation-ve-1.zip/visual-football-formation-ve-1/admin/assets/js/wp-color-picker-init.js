/*
 * initialization of the wp color picker
 */
jQuery(document).ready(function($) {

  'use strict';

  $('.wp-color-picker').wpColorPicker();

});